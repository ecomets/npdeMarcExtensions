library(testthat)
library(devnpde)

test_check("devnpde")
